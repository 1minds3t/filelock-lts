API
===

.. automodule:: filelock
    :members:
    :show-inheritance:
