License
=======

*py-filelock* is public domain:

.. literalinclude:: ../LICENSE
